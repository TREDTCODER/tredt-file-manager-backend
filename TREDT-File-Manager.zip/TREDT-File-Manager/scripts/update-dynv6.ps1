Invoke-WebRequest -Uri "https://dynv6.com/api/update?hostname=tredt-files.dynv6.net&token=2U4XqvZcysC82yBUMrjIqlutXPKSF28i&ipv6=auto"
